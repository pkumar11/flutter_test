import 'package:flutter/material.dart';
import 'package:web_socket_channel/io.dart';
import 'package:th_app/home_page_one.dart';

import 'home_list.dart';
import 'util/socket_singleton.dart';
void main() => runApp(MyApp());


class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  SocketSingleton singleton = SocketSingleton();

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData.dark(),
      home: HomeList(),
      //MyHomePageOne(channel: IOWebSocketChannel.connect("ws://192.168.1.31:3000/")),
      debugShowCheckedModeBanner: false,
    );
  }

  @override
  void dispose() {
    singleton.channel.sink.close();
    super.dispose();
  }

}


